from django import forms
from multiselectfield import MultiSelectFormField


class EnquiryForm(forms.Form):
    name = forms.CharField(
        label="Enter your name",
        widget=forms.TextInput(
            attrs={
                'placeholder': 'your name',
                'class': 'form-control'
            }
        )
    )
    mobile = forms.IntegerField(
        label="enter your mobile number",
        widget=forms.NumberInput(
            attrs={
                'placeholder': 'your mobile number',
                'class': 'form-control'
            }
        )
    )
    email = forms.EmailField(
        label="enter your email id",
        widget=forms.EmailInput(
            attrs={
                'placeholder': 'your email id',
                'class': 'form-control'
            }
        )
    )
    COURSE_CHOICES = (
        ('PYTHON', 'python'),
        ('DJANGO', 'django'),
        ('UI', 'ui'),
        ('REST API', 'rest api')

    )
    courses = MultiSelectFormField(choices=COURSE_CHOICES, label="select required courses:")

    TRAINER_CHOICES = (
        ('SAI', 'sai'),
        ('NANI', 'nani'),
        ('SATYA', 'satya')
    )
    trainers = MultiSelectFormField(choices=TRAINER_CHOICES, label="select required trainers: ")

    BRANCHES_CHOICES = (
        ('HYD', 'hyd'),
        ('PUNE', 'pune'),
        ('RANGOLI', 'rangoli')
    )
    branches = MultiSelectFormField(choices=BRANCHES_CHOICES, label="select required branches:")

    GENDER_CHOICES = (
        ('MALE', 'male'),
        ('FEAMALE', 'female')
    )
    gender = forms.ChoiceField(
        widget=forms.RadioSelect(), choices=GENDER_CHOICES,
        label="select your gender"
    )
    Start_date = forms.DateField(
        widget=forms.SelectDateWidget()
    )