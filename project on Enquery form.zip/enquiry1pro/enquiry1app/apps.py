from django.apps import AppConfig


class Enquiry1AppConfig(AppConfig):
    name = 'enquiry1app'
