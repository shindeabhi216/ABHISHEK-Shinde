from django.db import models
from multiselectfield import MultiSelectField

class enquirydata(models.Model):
    name=models.CharField(max_length=100)
    mobile=models.BigIntegerField()
    email=models.EmailField()

    COURSE_CHOICES=(
        ('PYTHON','python'),
        ('DJANGO','django'),
        ('UI','ui'),
        ('REST API','rest api')

    )
    courses=MultiSelectField(choices=COURSE_CHOICES,max_length=200)

    TRAINER_CHOICES=(
        ('SAI','sai'),
        ('NANI','nani'),
        ('SATYA','satya')
    )
    trainers=MultiSelectField(choices=TRAINER_CHOICES,max_length=200)

    BRANCHES_CHOICES=(
        ('HYD','hyd'),
        ('PUNE','pune'),
        ('RANGOLI','rangoli')
    )
    branches=MultiSelectField(choices=BRANCHES_CHOICES,max_length=200)

    gender=models.CharField(max_length=100)
    start_date=models.DateField(max_length=100)


