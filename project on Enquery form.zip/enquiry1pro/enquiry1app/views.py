from django.shortcuts import render
from enquiry1app.models import enquirydata
from enquiry1app.forms import EnquiryForm
from django.http.response import HttpResponse


def enquiryview(request):
    if request.method=="POST":
        eform=EnquiryForm(request.POST)
        if eform.is_valid():
            name=request.POST.get('name')
            mobile=request.POST.get('mobile')
            email=request.POST.get('email')
            courses=eform.cleaned_data.get('courses')
            trainers=eform.cleaned_data.get('trainers')
            branches=eform.cleaned_data.get('branches')
            gender=eform.cleaned_data.get('gender')
            start_date=eform.cleaned_data.get('start_date')

            data=enquirydata(
                name=name,
                mobile=mobile,
                email=email,
                courses=courses,
                trainers=trainers,
                branches=branches,
                gender=gender,
                start_date=start_date
                 )
            data.save()
            eform=EnquiryForm()
            return render(request,"enquiryfile.html",{'eform':eform})
        else:
            return HttpResponse("USER MISSED VALUES")
    else:
        eform=EnquiryForm()
        return render(request,"enquiryfile.html",{'eform':eform})







