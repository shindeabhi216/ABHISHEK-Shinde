from django.apps import AppConfig


class StudenatdataappConfig(AppConfig):
    name = 'studenatdataapp'
