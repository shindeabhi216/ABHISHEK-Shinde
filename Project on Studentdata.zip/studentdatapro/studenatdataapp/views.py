from django.shortcuts import render,redirect
from .models import StudentData

def home_page(request):
    students=StudentData.objects.all()
    return render(request,'studentdataapp/homepage.html',{'students':students})

def add_student_view(request):
    roll1=request.POST.get('roll')


