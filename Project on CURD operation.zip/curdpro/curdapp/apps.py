from django.apps import AppConfig


class CurdappConfig(AppConfig):
    name = 'curdapp'
