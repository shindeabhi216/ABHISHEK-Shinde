from django.shortcuts import render

def home(request):
    return render(request,'yourhtml.html')

def about(request):
    return render (request,'about.html')

def contact(request):
    return render (request,'contact.html')

def education(request):
    return render (request,'education.html')

def service(request):
    return render (request,'service.html')

def index(request):
    return render (request,'about.html')